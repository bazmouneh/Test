// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ka locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ka';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "aboutUs": MessageLookupByLibrary.simpleMessage("ჩვენს შესახებ"),
        "account": MessageLookupByLibrary.simpleMessage("ანგარიში:"),
        "accountNumber":
            MessageLookupByLibrary.simpleMessage("ანგარიშის ნომერი"),
        "accountNumberDoestMatched": MessageLookupByLibrary.simpleMessage(
            "ანგარიშის ნომერი არ ემთხვევა..!"),
        "add": MessageLookupByLibrary.simpleMessage("დამატება"),
        "addMoneyToYourWalletToRecharge": MessageLookupByLibrary.simpleMessage(
            "დაამატეთ ფული თქვენს საფულეში"),
        "addNewAddress":
            MessageLookupByLibrary.simpleMessage("დაამატეთ ახალი მისამართი"),
        "addRatings":
            MessageLookupByLibrary.simpleMessage("დაამატეთ რეიტინგები"),
        "address": MessageLookupByLibrary.simpleMessage("მისამართი"),
        "addressType": MessageLookupByLibrary.simpleMessage("მისამართის ტიპი"),
        "addresses": MessageLookupByLibrary.simpleMessage("მისამართები"),
        "amount": MessageLookupByLibrary.simpleMessage("თანხა"),
        "and": MessageLookupByLibrary.simpleMessage("და"),
        "appName": MessageLookupByLibrary.simpleMessage("დაჯავშნა\nსაქართველო"),
        "applyCoupon": MessageLookupByLibrary.simpleMessage("მიმართეთ კუპონს"),
        "applyFiltersAccordingToYourNeed": MessageLookupByLibrary.simpleMessage(
            "გამოიყენეთ ფილტრები თქვენი საჭიროების მიხედვით"),
        "appointmentBooked":
            MessageLookupByLibrary.simpleMessage("შეხვედრა დაჯავშნილია"),
        "appointmentId": MessageLookupByLibrary.simpleMessage("დანიშვნის ID"),
        "apr": MessageLookupByLibrary.simpleMessage("აპრ"),
        "april": MessageLookupByLibrary.simpleMessage("აპრილი"),
        "atSalon": MessageLookupByLibrary.simpleMessage("სალონში"),
        "attachLocation":
            MessageLookupByLibrary.simpleMessage("მიამაგრეთ მდებარეობა"),
        "aug": MessageLookupByLibrary.simpleMessage("აგვ"),
        "august": MessageLookupByLibrary.simpleMessage("აგვისტო"),
        "availability": MessageLookupByLibrary.simpleMessage("ხელმისაწვდომობა"),
        "awards": MessageLookupByLibrary.simpleMessage("ჯილდოები"),
        "bankName": MessageLookupByLibrary.simpleMessage("ბანკის სახელი"),
        "barber": MessageLookupByLibrary.simpleMessage("დალაქი"),
        "beTheBestVersionOfYourself": MessageLookupByLibrary.simpleMessage(
            "იყავი საკუთარი თავის საუკეთესო ვერსია"),
        "bookAppointment":
            MessageLookupByLibrary.simpleMessage("Book Appointment"),
        "bookService": MessageLookupByLibrary.simpleMessage("წიგნის სერვისი"),
        "bookingConfirmed":
            MessageLookupByLibrary.simpleMessage("დაჯავშნა დადასტურებულია"),
        "bookingDetails":
            MessageLookupByLibrary.simpleMessage("დაჯავშნის დეტალები"),
        "bookingId": MessageLookupByLibrary.simpleMessage("დაჯავშნის ID"),
        "bookingPending":
            MessageLookupByLibrary.simpleMessage("დაჯავშნა მოლოდინშია"),
        "bookings": MessageLookupByLibrary.simpleMessage("ჯავშნები"),
        "by": MessageLookupByLibrary.simpleMessage("ავტორი"),
        "byContinuingWithAnyOptions": MessageLookupByLibrary.simpleMessage(
            "ნებისმიერი ვარიანტის გაგრძელებით,"),
        "cancel": MessageLookupByLibrary.simpleMessage("გაუქმება"),
        "cancelBooking":
            MessageLookupByLibrary.simpleMessage("დაჯავშნის გაუქმება"),
        "cancelledBySalon":
            MessageLookupByLibrary.simpleMessage("გაუქმებულია სალონის მიერ"),
        "cancelledByYou":
            MessageLookupByLibrary.simpleMessage("გაუქმებულია თქვენ მიერ"),
        "categories": MessageLookupByLibrary.simpleMessage("კატეგორიები"),
        "change": MessageLookupByLibrary.simpleMessage("შეცვლა"),
        "changeLanguage": MessageLookupByLibrary.simpleMessage("ენის შეცვლა"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("პაროლის შეცვლა"),
        "checkAppointmentsTabnforAllYourUpcomingAppointments":
            MessageLookupByLibrary.simpleMessage(
                "შეამოწმეთ დანიშვნების ჩანართი\nყველა თქვენი მომავალი შეხვედრისთვის"),
        "chooseBarberFirst":
            MessageLookupByLibrary.simpleMessage("ჯერ დალაქი აირჩიე...!"),
        "chooseYourExpert":
            MessageLookupByLibrary.simpleMessage("აირჩიეთ თქვენი ექსპერტი"),
        "city": MessageLookupByLibrary.simpleMessage("ქალაქი"),
        "clearAll": MessageLookupByLibrary.simpleMessage("გაასუფთავე ყველა"),
        "clickOnAnyAddressToSelect": MessageLookupByLibrary.simpleMessage(
            "● ასარჩევად დააწკაპუნეთ ნებისმიერ მისამართზე."),
        "clickToFetchLocation": MessageLookupByLibrary.simpleMessage(
            "დააწკაპუნეთ მდებარეობის მისაღებად"),
        "closed": MessageLookupByLibrary.simpleMessage("დახურულია"),
        "completeBooking":
            MessageLookupByLibrary.simpleMessage("სრული დაჯავშნა"),
        "completed": MessageLookupByLibrary.simpleMessage("დასრულებული"),
        "completedOrders":
            MessageLookupByLibrary.simpleMessage("დასრულებული შეკვეთები"),
        "completionOtp": MessageLookupByLibrary.simpleMessage("OTP დასრულება:"),
        "confirmBarber":
            MessageLookupByLibrary.simpleMessage("დაადასტურეთ ბარბერი"),
        "confirmBooking":
            MessageLookupByLibrary.simpleMessage("დაადასტურეთ დაჯავშნა"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("დაადასტურეთ პაროლი"),
        "contactUs": MessageLookupByLibrary.simpleMessage("დაგვიკავშირდით"),
        "continue_": MessageLookupByLibrary.simpleMessage("განაგრძეთ"),
        "country": MessageLookupByLibrary.simpleMessage("ქვეყანა"),
        "couponDiscount":
            MessageLookupByLibrary.simpleMessage("კუპონის ფასდაკლება"),
        "dash": MessageLookupByLibrary.simpleMessage("-"),
        "date": MessageLookupByLibrary.simpleMessage("თარიღი"),
        "dec": MessageLookupByLibrary.simpleMessage("დეკ"),
        "december": MessageLookupByLibrary.simpleMessage("დეკემბერი"),
        "delete": MessageLookupByLibrary.simpleMessage("წაშლა"),
        "deleteAddress":
            MessageLookupByLibrary.simpleMessage("მისამართის წაშლა"),
        "deleteDesc": MessageLookupByLibrary.simpleMessage(
            "ნამდვილად გსურთ თქვენი ანგარიშის წაშლა?\nთქვენი ყველა მონაცემი წაიშლება და თქვენ ვერ\nშეძლებთ მის აღდგენას ხელახლა !\n\nნამდვილად გსურთ გაგრძელება?"),
        "deleteForMe": MessageLookupByLibrary.simpleMessage("წაშალე ჩემთვის"),
        "deleteMessage":
            MessageLookupByLibrary.simpleMessage("შეტყობინების წაშლა"),
        "deleteMyAccount":
            MessageLookupByLibrary.simpleMessage("წაშალე ჩემი ანგარიში"),
        "deposit": MessageLookupByLibrary.simpleMessage("ანაბარი"),
        "details": MessageLookupByLibrary.simpleMessage("დეტალები"),
        "doYouReallyWantToCancelThisBookingnthisActionCant":
            MessageLookupByLibrary.simpleMessage(
                "ნამდვილად გსურთ ამ ჯავშნის გაუქმება?\nამ მოქმედების გაუქმება შეუძლებელია"),
        "done": MessageLookupByLibrary.simpleMessage("შესრულებულია"),
        "duration": MessageLookupByLibrary.simpleMessage("ხანგრძლივობა"),
        "edit": MessageLookupByLibrary.simpleMessage("რედაქტირება"),
        "editDetails":
            MessageLookupByLibrary.simpleMessage("დეტალების რედაქტირება"),
        "editProfile":
            MessageLookupByLibrary.simpleMessage("პროფილის რედაქტირება"),
        "emailAddress":
            MessageLookupByLibrary.simpleMessage("ელ.ფოსტის მისამართი"),
        "emailRegistration":
            MessageLookupByLibrary.simpleMessage("ელ.ფოსტის რეგისტრაცია"),
        "enterAccountNumber": MessageLookupByLibrary.simpleMessage(
            "შეიყვანეთ ანგარიშის ნომერი..!"),
        "enterAmountOfYourChoice": MessageLookupByLibrary.simpleMessage(
            "შეიყვანეთ თქვენი არჩევანის ოდენობა"),
        "enterBankName":
            MessageLookupByLibrary.simpleMessage("შეიყვანეთ ბანკის სახელი..!"),
        "enterHoldersName": MessageLookupByLibrary.simpleMessage(
            "შეიყვანეთ მფლობელის სახელი..!"),
        "enterReaccountNumber": MessageLookupByLibrary.simpleMessage(
            "ხელახლა შეიყვანეთ ანგარიშის ნომერი..!"),
        "enterSwiftCode":
            MessageLookupByLibrary.simpleMessage("შეიყვანეთ Swift კოდი..!"),
        "enterYourDetailsAndCompleteProfileForBetterExperience":
            MessageLookupByLibrary.simpleMessage(
                "შეიყვანეთ თქვენი დეტალები და შეავსეთ\nპროფილი უკეთესი გამოცდილებისთვის"),
        "enterYourEmailAddressOnWhichWeWillSendYouTheLinkToResetThePassword":
            MessageLookupByLibrary.simpleMessage(
                "შეიყვანეთ თქვენი ელფოსტის მისამართი, რომელზეც ჩვენ\nგამოგიგზავნით ბმულს პაროლის აღდგენისთვის."),
        "enterYourFullname": MessageLookupByLibrary.simpleMessage(
            "შეიყვანეთ თქვენი სრული სახელი..!"),
        "explore": MessageLookupByLibrary.simpleMessage("გამოიკვლიეთ"),
        "exploreSalonsOnMap":
            MessageLookupByLibrary.simpleMessage("გამოიკვლიეთ სალონები რუკაზე"),
        "favourite": MessageLookupByLibrary.simpleMessage("საყვარელი"),
        "feb": MessageLookupByLibrary.simpleMessage("თებ"),
        "february": MessageLookupByLibrary.simpleMessage("თებერვალი"),
        "female": MessageLookupByLibrary.simpleMessage("ქალი"),
        "filters": MessageLookupByLibrary.simpleMessage("ფილტრები"),
        "findAndBookHairCutMassageSpaWaxingColoringServicesAnytime":
            MessageLookupByLibrary.simpleMessage(
                "იპოვეთ და დაჯავშნეთ თმის შეჭრა, მასაჟი, სპა,\nეპილინგის, შეღებვის სერვისები ნებისმიერ დროს."),
        "forQuestionsAndQueries": MessageLookupByLibrary.simpleMessage(
            "კითხვებისა და შეკითხვებისთვის"),
        "forgotPassword_":
            MessageLookupByLibrary.simpleMessage("დაგავიწყდათ პაროლი?"),
        "forgotYourPassword":
            MessageLookupByLibrary.simpleMessage("დაგავიწყდათ პაროლი?"),
        "fullName": MessageLookupByLibrary.simpleMessage("სრული სახელი"),
        "fundsHaveBeenAddedntoYourAccountSuccessfully":
            MessageLookupByLibrary.simpleMessage(
                "თანხები\nთქვენს ანგარიშზე წარმატებით დაემატა!"),
        "gallery": MessageLookupByLibrary.simpleMessage("გალერეა"),
        "helpAndFAQ": MessageLookupByLibrary.simpleMessage(
            "დახმარება და ხშირად დასმული კითხვები"),
        "help_FAQ": MessageLookupByLibrary.simpleMessage(
            "დახმარება და ხშირად დასმული კითხვები"),
        "history": MessageLookupByLibrary.simpleMessage("ისტორია"),
        "holdersName": MessageLookupByLibrary.simpleMessage("მფლობელის სახელი"),
        "home": MessageLookupByLibrary.simpleMessage("მთავარი"),
        "jan": MessageLookupByLibrary.simpleMessage("იან"),
        "january": MessageLookupByLibrary.simpleMessage("იანვარი"),
        "jul": MessageLookupByLibrary.simpleMessage("ივლისი"),
        "july": MessageLookupByLibrary.simpleMessage("ივლისი"),
        "jun": MessageLookupByLibrary.simpleMessage("ივნ"),
        "june": MessageLookupByLibrary.simpleMessage("ივნისი"),
        "keepItOnIfYouWantToReceiveNotifications":
            MessageLookupByLibrary.simpleMessage(
                "შეინახეთ ჩართული, თუ გსურთ მიიღოთ შეტყობინებები"),
        "localityArea": MessageLookupByLibrary.simpleMessage("რაიონი / ფართი"),
        "locationFetched":
            MessageLookupByLibrary.simpleMessage("მდებარეობა მიღებულია"),
        "locationServiceIsDisabled": MessageLookupByLibrary.simpleMessage(
            "მდებარეობის სერვისი გამორთულია"),
        "logOut": MessageLookupByLibrary.simpleMessage("გასვლა"),
        "logoutDec":
            MessageLookupByLibrary.simpleMessage("ნამდვილად გსურთ გამოსვლა?"),
        "makePayment": MessageLookupByLibrary.simpleMessage("გადახდა"),
        "male": MessageLookupByLibrary.simpleMessage("მამრობითი"),
        "mar": MessageLookupByLibrary.simpleMessage("მარ"),
        "march": MessageLookupByLibrary.simpleMessage("მარტი"),
        "may": MessageLookupByLibrary.simpleMessage("მაისი"),
        "messages": MessageLookupByLibrary.simpleMessage("შეტყობინებები"),
        "mondayFriday":
            MessageLookupByLibrary.simpleMessage("ორშაბათი - პარასკევი"),
        "myAddress": MessageLookupByLibrary.simpleMessage("ჩემი მისამართი"),
        "myAddresses": MessageLookupByLibrary.simpleMessage("ჩემი მისამართები"),
        "myBooking": MessageLookupByLibrary.simpleMessage("ჩემი ჯავშნები"),
        "myBookings": MessageLookupByLibrary.simpleMessage("ჩემი ჯავშნები"),
        "navigate": MessageLookupByLibrary.simpleMessage("ნავიგაცია"),
        "nearBySalons":
            MessageLookupByLibrary.simpleMessage("ახლომდებარე სალონები"),
        "newPassword": MessageLookupByLibrary.simpleMessage("ახალი პაროლი"),
        "newUserRegisterHere": MessageLookupByLibrary.simpleMessage(
            "ახალი მომხმარებელი? დარეგისტრირდით აქ"),
        "noSlotsAvailable": MessageLookupByLibrary.simpleMessage(
            "სლოტები არ არის ხელმისაწვდომი"),
        "notAvailable": MessageLookupByLibrary.simpleMessage("მიუწვდომელია"),
        "notifications": MessageLookupByLibrary.simpleMessage("შეტყობინებები"),
        "nov": MessageLookupByLibrary.simpleMessage("ნოემ"),
        "november": MessageLookupByLibrary.simpleMessage("ნოემბერი"),
        "nowYouCanBookAppointmentsnwithSingleClickToAvoidDisturbance":
            MessageLookupByLibrary.simpleMessage(
                "ახლა თქვენ შეგიძლიათ დაჯავშნოთ შეხვედრები\nერთი დაწკაპუნებით, რათა თავიდან აიცილოთ შეშფოთება."),
        "oct": MessageLookupByLibrary.simpleMessage("ოქტ"),
        "october": MessageLookupByLibrary.simpleMessage("ოქტომბერი"),
        "offerThisQRAtSalonShopTheyWillScanItAndWillHaveAllTheDetails":
            MessageLookupByLibrary.simpleMessage(
                "შესთავაზეთ ეს QR სალონის მაღაზიაში, ისინი\nდასკანირებენ და ექნებათ ყველა დეტალი"),
        "offeredBy": MessageLookupByLibrary.simpleMessage("შესთავაზა"),
        "office": MessageLookupByLibrary.simpleMessage("ოფისი"),
        "oldPassword": MessageLookupByLibrary.simpleMessage("ძველი პაროლი"),
        "oldPasswordIsWrong":
            MessageLookupByLibrary.simpleMessage("ძველი პაროლი არასწორია..!"),
        "one": MessageLookupByLibrary.simpleMessage("1"),
        "open": MessageLookupByLibrary.simpleMessage("გახსენით"),
        "other": MessageLookupByLibrary.simpleMessage("სხვა"),
        "otherLocation":
            MessageLookupByLibrary.simpleMessage("სხვა ადგილმდებარეობა"),
        "password": MessageLookupByLibrary.simpleMessage("პაროლი"),
        "passwordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage("პაროლი არ ემთხვევა"),
        "payAfterService":
            MessageLookupByLibrary.simpleMessage("გადახდა მომსახურების შემდეგ"),
        "payNow": MessageLookupByLibrary.simpleMessage("გადაიხადე ახლა"),
        "payableAmount":
            MessageLookupByLibrary.simpleMessage("გადასახდელი თანხა"),
        "paymentCancelled":
            MessageLookupByLibrary.simpleMessage("გადახდა გაუქმდა"),
        "paymentFailed":
            MessageLookupByLibrary.simpleMessage("გადახდა ვერ მოხერხდა..!"),
        "paymentType": MessageLookupByLibrary.simpleMessage("გადახდის ტიპი"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("ტელეფონის ნომერი"),
        "phoneNumberOptional": MessageLookupByLibrary.simpleMessage(
            "ტელეფონის ნომერი (სურვილისამებრ)"),
        "pinCode": MessageLookupByLibrary.simpleMessage("PIN კოდი"),
        "placeBooking":
            MessageLookupByLibrary.simpleMessage("ადგილის დაჯავშნა"),
        "pleaseEnterAddress": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ მისამართი...!"),
        "pleaseEnterCity":
            MessageLookupByLibrary.simpleMessage("გთხოვთ შედით ქალაქში...!"),
        "pleaseEnterConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ, შეიყვანოთ დაადასტურეთ პაროლი"),
        "pleaseEnterCountry":
            MessageLookupByLibrary.simpleMessage("გთხოვთ შედით ქვეყანაში...!"),
        "pleaseEnterEmailAddress": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ ელექტრონული ფოსტის მისამართი"),
        "pleaseEnterFullname": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ სრული სახელი"),
        "pleaseEnterLocalityarea": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ რაიონი/რაიონი...!"),
        "pleaseEnterNewPassword": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ ახალი პაროლი..!"),
        "pleaseEnterOldPassword": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ ძველი პაროლი..!"),
        "pleaseEnterPassword":
            MessageLookupByLibrary.simpleMessage("გთხოვთ შეიყვანოთ პაროლი"),
        "pleaseEnterPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ ტელეფონის ნომერი...!"),
        "pleaseEnterPinCode": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ PIN კოდი...!"),
        "pleaseEnterReview":
            MessageLookupByLibrary.simpleMessage("გთხოვთ დაწეროთ მიმოხილვა..!"),
        "pleaseEnterState": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ შეიყვანოთ სახელმწიფო...!"),
        "pleaseEnterValidEmailAddress": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ, შეიყვანოთ სწორი ელფოსტის მისამართი"),
        "pleaseProvideThisOtpAtSalonWhenAskedOnlyAfter":
            MessageLookupByLibrary.simpleMessage(
                "გთხოვთ, მიაწოდოთ ეს OTP სალონში მოთხოვნის შემთხვევაში, მხოლოდ მას შემდეგ, რაც მიიღებთ თქვენს მომსახურებას შეკვეთის მიხედვით."),
        "pleaseRechargeYourWalletToContinueBooking":
            MessageLookupByLibrary.simpleMessage(
                "გთხოვთ, შეავსოთ თქვენი საფულე დაჯავშნის გასაგრძელებლად"),
        "pleaseRegistrationFirst": MessageLookupByLibrary.simpleMessage(
            "ჯერ დაასრულეთ რეგისტრაცია..!"),
        "pleaseSelectAddress": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ, აირჩიოთ მისამართი...!"),
        "pleaseSelectAtLeast1Star": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ, აირჩიოთ მინიმუმ 1 ვარსკვლავი."),
        "pleaseSelectDate":
            MessageLookupByLibrary.simpleMessage("გთხოვთ, აირჩიოთ თარიღი"),
        "pleaseSelectLocation": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ, აირჩიოთ მდებარეობა...!"),
        "pleaseSelectTime":
            MessageLookupByLibrary.simpleMessage("გთხოვთ, აირჩიოთ დრო"),
        "pleaseVerifyEmailFirst": MessageLookupByLibrary.simpleMessage(
            "გთხოვთ, ჯერ გადაამოწმოთ თქვენი ელ..!"),
        "popularSearch":
            MessageLookupByLibrary.simpleMessage("პოპულარული ძებნა"),
        "premiumBeautyServices":
            MessageLookupByLibrary.simpleMessage("პრემიუმ სილამაზის სერვისები"),
        "prepaid": MessageLookupByLibrary.simpleMessage("წინასწარ გადახდილი"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("კონფიდენციალურობის პოლიტიკა"),
        "proceed": MessageLookupByLibrary.simpleMessage("გაგრძელება"),
        "profile": MessageLookupByLibrary.simpleMessage("პროფილი"),
        "purchase": MessageLookupByLibrary.simpleMessage("შეძენა"),
        "pushNotification":
            MessageLookupByLibrary.simpleMessage("Push შეტყობინება"),
        "rateNow": MessageLookupByLibrary.simpleMessage("შეაფასეთ ახლა"),
        "rateThisSaloon":
            MessageLookupByLibrary.simpleMessage("შეაფასეთ ეს სალონი"),
        "ratings": MessageLookupByLibrary.simpleMessage("რეიტინგები"),
        "reEnterAccountNumber": MessageLookupByLibrary.simpleMessage(
            "ხელახლა შეიყვანეთ ანგარიშის ნომერი"),
        "recent": MessageLookupByLibrary.simpleMessage("ბოლო"),
        "rechargeWallet":
            MessageLookupByLibrary.simpleMessage("საფულის შევსება"),
        "refund": MessageLookupByLibrary.simpleMessage("თანხის დაბრუნება"),
        "reschedule": MessageLookupByLibrary.simpleMessage("გადაგეგმვა"),
        "reviews": MessageLookupByLibrary.simpleMessage("მიმოხილვები"),
        "salon": MessageLookupByLibrary.simpleMessage("სალონი"),
        "salons": MessageLookupByLibrary.simpleMessage("სალონები"),
        "saturdaySunday":
            MessageLookupByLibrary.simpleMessage("შაბათი - კვირა"),
        "save": MessageLookupByLibrary.simpleMessage("შენახვა"),
        "search": MessageLookupByLibrary.simpleMessage("ძიება"),
        "seeAll": MessageLookupByLibrary.simpleMessage("იხილეთ ყველა"),
        "selectAddress":
            MessageLookupByLibrary.simpleMessage("აირჩიეთ მისამართი"),
        "selectAmount": MessageLookupByLibrary.simpleMessage("აირჩიეთ თანხა"),
        "selectAnother": MessageLookupByLibrary.simpleMessage("აირჩიეთ სხვა"),
        "selectDate": MessageLookupByLibrary.simpleMessage("აირჩიეთ თარიღი"),
        "selectMsg":
            MessageLookupByLibrary.simpleMessage("აირჩიეთ შეტყობინება"),
        "selectSlot": MessageLookupByLibrary.simpleMessage("აირჩიეთ სლოტი"),
        "selectTime": MessageLookupByLibrary.simpleMessage("აირჩიეთ დრო"),
        "send": MessageLookupByLibrary.simpleMessage("გაგზავნა"),
        "sendMedia": MessageLookupByLibrary.simpleMessage("მედიის გაგზავნა"),
        "sep": MessageLookupByLibrary.simpleMessage("სექ"),
        "september": MessageLookupByLibrary.simpleMessage("სექტემბერი"),
        "service": MessageLookupByLibrary.simpleMessage("სერვისი"),
        "serviceLocation":
            MessageLookupByLibrary.simpleMessage("სერვისის ადგილმდებარეობა"),
        "services": MessageLookupByLibrary.simpleMessage("სერვისები"),
        "shareYourExperienceInFewWords": MessageLookupByLibrary.simpleMessage(
            "გაგვიზიარეთ თქვენი გამოცდილება რამდენიმე სიტყვით"),
        "shareYourExperienceWithUs": MessageLookupByLibrary.simpleMessage(
            "გაგვიზიარეთ თქვენი გამოცდილება."),
        "showThisQRAtSalon":
            MessageLookupByLibrary.simpleMessage("აჩვენე ეს QR სალონში"),
        "signInToContinue":
            MessageLookupByLibrary.simpleMessage("შედით გასაგრძელებლად"),
        "signInWithApple":
            MessageLookupByLibrary.simpleMessage("შესვლა Apple-ით"),
        "signInWithEmail":
            MessageLookupByLibrary.simpleMessage("შედით ელექტრონული ფოსტით"),
        "signInWithGoogle":
            MessageLookupByLibrary.simpleMessage("შედით Google-ით"),
        "slotsAvailable":
            MessageLookupByLibrary.simpleMessage("ხელმისაწვდომია სლოტები"),
        "somethingWentWrong":
            MessageLookupByLibrary.simpleMessage("რაღაც შეცდა"),
        "staff": MessageLookupByLibrary.simpleMessage("პერსონალი"),
        "state": MessageLookupByLibrary.simpleMessage("სახელმწიფო"),
        "statement": MessageLookupByLibrary.simpleMessage("განცხადება"),
        "subTotal": MessageLookupByLibrary.simpleMessage("სუბტოტალი"),
        "submit": MessageLookupByLibrary.simpleMessage("გაგზავნა"),
        "suggestionForYou":
            MessageLookupByLibrary.simpleMessage("წინადადებები თქვენთვის"),
        "suggestions": MessageLookupByLibrary.simpleMessage("წინადადებები"),
        "swiftCode": MessageLookupByLibrary.simpleMessage("Swift კოდი"),
        "tapOnACouponToApplyIt": MessageLookupByLibrary.simpleMessage(
            "შეეხეთ კუპონს მის გამოსაყენებლად"),
        "termsOfUse":
            MessageLookupByLibrary.simpleMessage("გამოყენების პირობები"),
        "thisVideoIsGreaterThan15MbnpleaseSelectAnother":
            MessageLookupByLibrary.simpleMessage(
                "ეს ვიდეო 15 მბაიტზე მეტია\nგთხოვთ აირჩიოთ სხვა..."),
        "time": MessageLookupByLibrary.simpleMessage("დრო"),
        "tooLarge": MessageLookupByLibrary.simpleMessage("ძალიან დიდი..!"),
        "topRated": MessageLookupByLibrary.simpleMessage("ყველაზე რეიტინგული"),
        "topRatedSalons":
            MessageLookupByLibrary.simpleMessage("ყველაზე რეიტინგული სალონები"),
        "totalAmount": MessageLookupByLibrary.simpleMessage("მთლიანი თანხა"),
        "totalBookings": MessageLookupByLibrary.simpleMessage("ჯავშნები"),
        "totalOrders": MessageLookupByLibrary.simpleMessage("სულ შეკვეთები:"),
        "transactionSuccessful":
            MessageLookupByLibrary.simpleMessage("ტრანზაქცია წარმატებულია"),
        "unisex": MessageLookupByLibrary.simpleMessage("უნისექსი"),
        "unknown": MessageLookupByLibrary.simpleMessage("უცნობი"),
        "upcoming": MessageLookupByLibrary.simpleMessage("მომავალი"),
        "userAlreadyExist":
            MessageLookupByLibrary.simpleMessage("მომხმარებელი უკვე არსებობს"),
        "video": MessageLookupByLibrary.simpleMessage("ვიდეო?"),
        "wallet": MessageLookupByLibrary.simpleMessage("საფულე"),
        "withdraw": MessageLookupByLibrary.simpleMessage("გაყვანა"),
        "withdrawDescription": MessageLookupByLibrary.simpleMessage(
            "ნამდვილად გსურთ მთელი თანხის ამოღება თქვენი საფულედან?"),
        "withdrawRequest":
            MessageLookupByLibrary.simpleMessage("ამოღების მოთხოვნა"),
        "withdrawRequests":
            MessageLookupByLibrary.simpleMessage("მოთხოვნების გატანა"),
        "withdrawTitle":
            MessageLookupByLibrary.simpleMessage("ამოღების მოთხოვნა"),
        "woman": MessageLookupByLibrary.simpleMessage("ქალი"),
        "wrongPassword":
            MessageLookupByLibrary.simpleMessage("არასწორი პაროლი..!"),
        "youAgreeTo":
            MessageLookupByLibrary.simpleMessage("თქვენ თანახმა ხართ"),
        "youCanMakeBookingsOnlyForTodayOrForThe":
            MessageLookupByLibrary.simpleMessage(
                "დაჯავშნა შეგიძლიათ მხოლოდ დღეს ან მომავალში 90 დღის განმავლობაში."),
        "yourAppointmentnhasBeenBookedSuccessfully":
            MessageLookupByLibrary.simpleMessage(
                "თქვენი შეხვედრა\n წარმატებით დაჯავშნა"),
        "yourReview": MessageLookupByLibrary.simpleMessage("თქვენი მიმოხილვა")
      };
}
