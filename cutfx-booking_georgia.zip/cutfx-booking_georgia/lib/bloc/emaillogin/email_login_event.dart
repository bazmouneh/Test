part of 'email_login_bloc.dart';

abstract class EmailLoginEvent {}

class ContinueLoginEvent extends EmailLoginEvent {}
