part of 'search_salon_bloc.dart';

abstract class SearchSalonState {}

class SearchSalonInitial extends SearchSalonState {}

class SalonDataFoundState extends SearchSalonState {}
