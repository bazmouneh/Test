part of 'search_salon_bloc.dart';

abstract class SearchSalonEvent {}

class FetchSalonEvent extends SearchSalonEvent {}

class UpdateDataRecentDataEvent extends SearchSalonEvent {}
