part of 'top_rated_salon_bloc.dart';

abstract class TopRatedSalonState {}

class TopRatedSalonInitial extends TopRatedSalonState {}

class FoundTopRatedSalonDataState extends TopRatedSalonState {}
