part of 'top_rated_salon_bloc.dart';

abstract class TopRatedSalonEvent {}

class FetchTopRatedSalon extends TopRatedSalonEvent {}

class UpdateTopRatedSalon extends TopRatedSalonEvent {}
