part of 'forgot_password_bloc.dart';

abstract class ForgotPasswordEvent {}

class ContinueForgotPasswordEvent extends ForgotPasswordEvent {}
