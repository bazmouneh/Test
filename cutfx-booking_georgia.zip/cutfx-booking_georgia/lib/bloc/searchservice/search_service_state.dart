part of 'search_service_bloc.dart';

abstract class SearchServiceState {}

class SearchServiceInitial extends SearchServiceState {}

class ServiceDataFoundState extends SearchServiceState {}
