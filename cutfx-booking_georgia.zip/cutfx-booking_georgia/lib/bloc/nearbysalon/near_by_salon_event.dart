part of 'near_by_salon_bloc.dart';

abstract class NearBySalonEvent {}

class FetchNearBySalonEvent extends NearBySalonEvent {}

class UpdateDataNearBySalonEvent extends NearBySalonEvent {}
