part of 'near_by_salon_bloc.dart';

abstract class NearBySalonState {}

class NearBySalonInitial extends NearBySalonState {}

class DataFoundNearBySalonState extends NearBySalonState {}
