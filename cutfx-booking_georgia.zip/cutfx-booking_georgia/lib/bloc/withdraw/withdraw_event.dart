part of 'withdraw_bloc.dart';

abstract class WithdrawEvent {}

class FetchWalletBalanceEvent extends WithdrawEvent {}
