part of 'withdraw_bloc.dart';

abstract class WithdrawState {}

class WithdrawInitial extends WithdrawState {}

class WithdrawDataFoundState extends WithdrawState {}
