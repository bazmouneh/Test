part of 'recharge_wallet_bloc.dart';

abstract class RechargeWalletState {}

class RechargeWalletInitial extends RechargeWalletState {}

class UserDataFoundRechargeWalletState extends RechargeWalletState {}
