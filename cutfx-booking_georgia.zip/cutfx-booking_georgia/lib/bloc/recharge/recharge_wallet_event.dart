part of 'recharge_wallet_bloc.dart';

abstract class RechargeWalletEvent {}

class FetchRechargeWalletEvent extends RechargeWalletEvent {}
