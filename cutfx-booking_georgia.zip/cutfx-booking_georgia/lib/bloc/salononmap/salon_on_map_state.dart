part of 'salon_on_map_bloc.dart';

abstract class SalonOnMapState {}

class SalonOnMapInitial extends SalonOnMapState {}

class DataFoundSalonOnMapState extends SalonOnMapState {}

class UpdateDataMapState extends SalonOnMapState {}
