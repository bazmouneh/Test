part of 'salon_on_map_bloc.dart';

abstract class SalonOnMapEvent {}

class FetchSalonOnMapEvent extends SalonOnMapEvent {}

class UpdateSalonOnMapEvent extends SalonOnMapEvent {}
