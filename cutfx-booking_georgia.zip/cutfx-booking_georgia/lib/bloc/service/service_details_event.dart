part of 'service_details_bloc.dart';

abstract class ServiceDetailsEvent {}

class FetchServiceDetailsEvent extends ServiceDetailsEvent {}
