part of 'bookings_bloc.dart';

abstract class BookingsEvent {}

class FetchBookingsArgumentsEvent extends BookingsEvent {}
