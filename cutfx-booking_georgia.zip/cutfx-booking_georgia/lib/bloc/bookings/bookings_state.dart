part of 'bookings_bloc.dart';

abstract class BookingsState {}

class BookingsInitial extends BookingsState {}

class BookingArgumentsFetchedState extends BookingsState {}
