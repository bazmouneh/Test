part of 'profile_bloc.dart';

abstract class ProfileEvent {}

class FetchUserDataEvent extends ProfileEvent {}
