part of 'salon_details_bloc.dart';

abstract class SalonDetailsEvent {}

class FetchSalonDataEvent extends SalonDetailsEvent {
  FetchSalonDataEvent();
}
