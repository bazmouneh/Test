part of 'add_address_bloc.dart';

class AddAddressState {}

class AddAddressInitial extends AddAddressState {}
