part of 'add_address_bloc.dart';

class AddAddressEvent {}
