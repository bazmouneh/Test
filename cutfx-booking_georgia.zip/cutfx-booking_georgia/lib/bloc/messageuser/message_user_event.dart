part of 'message_user_bloc.dart';

abstract class MessageUserEvent {}

class FetchMessageUserEvent extends MessageUserEvent {}
