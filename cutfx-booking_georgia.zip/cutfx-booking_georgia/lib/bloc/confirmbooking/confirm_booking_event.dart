part of 'confirm_booking_bloc.dart';

abstract class ConfirmBookingEvent {}

class FetchArgumentsEvent extends ConfirmBookingEvent {}
