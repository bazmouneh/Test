part of 'confirm_booking_bloc.dart';

abstract class ConfirmBookingState {}

class ConfirmBookingInitial extends ConfirmBookingState {}

class ArgumentDataFetchedEvent extends ConfirmBookingState {}
