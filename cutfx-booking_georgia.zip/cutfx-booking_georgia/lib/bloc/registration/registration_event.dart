part of 'registration_bloc.dart';

abstract class RegistrationEvent {}

class ContinueRegistrationEvent extends RegistrationEvent {}
