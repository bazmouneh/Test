part of 're_schedule_bloc.dart';

abstract class ReScheduleState {}

class ReScheduleInitial extends ReScheduleState {}

class UpdateReScheduleDataState extends ReScheduleState {}
