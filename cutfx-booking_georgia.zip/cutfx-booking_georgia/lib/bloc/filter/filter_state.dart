part of 'filter_bloc.dart';

abstract class FilterState {}

class FilterInitial extends FilterState {}

class CategoriesFetchedState extends FilterState {}
