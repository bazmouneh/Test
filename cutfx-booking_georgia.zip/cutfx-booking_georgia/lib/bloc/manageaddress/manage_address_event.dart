part of 'manage_address_bloc.dart';

class ManageAddressEvent {}

class FetchAddressEvent extends ManageAddressEvent {}
