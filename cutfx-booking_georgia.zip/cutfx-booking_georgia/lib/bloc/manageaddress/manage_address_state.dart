part of 'manage_address_bloc.dart';

class ManageAddressState {}

class ManageAddressInitial extends ManageAddressState {}

class DataFoundAddressState extends ManageAddressState {}
