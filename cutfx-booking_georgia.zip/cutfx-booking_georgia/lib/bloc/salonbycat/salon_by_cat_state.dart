part of 'salon_by_cat_bloc.dart';

abstract class SalonByCatState {}

class SalonByCatInitial extends SalonByCatState {}

class FetchSalonByCatState extends SalonByCatState {}
