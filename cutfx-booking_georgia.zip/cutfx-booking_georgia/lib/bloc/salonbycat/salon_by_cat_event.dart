part of 'salon_by_cat_bloc.dart';

abstract class SalonByCatEvent {}

class FetchSalonByCatEvent extends SalonByCatEvent {}
