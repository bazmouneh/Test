part of 'home_bloc.dart';

abstract class HomeEvent {}

class FetchHomeDataEvent extends HomeEvent {}

class FetchNearBySalonEvent extends HomeEvent {}
