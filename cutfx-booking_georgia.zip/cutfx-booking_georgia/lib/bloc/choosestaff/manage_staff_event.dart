part of 'manage_staff_bloc.dart';

class ManageStaffEvent {}

class FetchManageStaffEvent extends ManageStaffEvent {}

class SelectStaffEvent extends ManageStaffEvent {}
