part of 'add_rating_bloc.dart';

abstract class AddRatingEvent {}

class ChangeReviewEvent extends AddRatingEvent {}
