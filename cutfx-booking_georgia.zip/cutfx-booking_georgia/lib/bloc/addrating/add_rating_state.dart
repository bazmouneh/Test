part of 'add_rating_bloc.dart';

abstract class AddRatingState {}

class AddRatingInitial extends AddRatingState {}

class ChangeReviewState extends AddRatingState {}
