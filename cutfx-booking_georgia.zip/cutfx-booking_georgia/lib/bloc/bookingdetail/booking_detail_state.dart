part of 'booking_detail_bloc.dart';

abstract class BookingDetailState {}

class BookingDetailInitial extends BookingDetailState {}

class BookingDetailSlotsInitial extends BookingDetailState {}

class BookingDetailDataFoundState extends BookingDetailState {}

class BookingDetailSlotsDataFoundState extends BookingDetailState {}
