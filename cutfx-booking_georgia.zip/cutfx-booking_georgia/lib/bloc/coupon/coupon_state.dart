part of 'coupon_bloc.dart';

abstract class CouponState {}

class CouponInitial extends CouponState {}

class CouponDataFoundState extends CouponState {}
