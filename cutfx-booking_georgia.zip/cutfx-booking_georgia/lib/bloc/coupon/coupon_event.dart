part of 'coupon_bloc.dart';

abstract class CouponEvent {}

class FetchCouponDataEvent extends CouponEvent {}
