part of 'add_awards_bloc.dart';

abstract class AddAwardsState {}

class AddAwardsInitial extends AddAwardsState {}

class ChangeTextState extends AddAwardsState {}
