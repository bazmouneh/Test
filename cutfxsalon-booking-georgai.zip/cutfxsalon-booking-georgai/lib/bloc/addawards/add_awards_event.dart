part of 'add_awards_bloc.dart';

abstract class AddAwardsEvent {}

class TextChangeEvent extends AddAwardsEvent {}
