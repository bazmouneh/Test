part of 'booking_history_bloc.dart';

abstract class BookingHistoryEvent {}

class FetchUpcomingHistoryEvent extends BookingHistoryEvent {}
