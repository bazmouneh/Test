part of 'booking_history_bloc.dart';

abstract class BookingHistoryState {}

class BookingHistoryInitial extends BookingHistoryState {}

class BookingHistoryDataFoundState extends BookingHistoryState {}
