part of 'request_bloc.dart';

abstract class RequestEvent {}

class GetRequestsEvent extends RequestEvent {}
