part of 'manage_staff_bloc.dart';

class ManageStaffState {}

class ManageStaffInitial extends ManageStaffState {}

class FetchStaffState extends ManageStaffState {}
