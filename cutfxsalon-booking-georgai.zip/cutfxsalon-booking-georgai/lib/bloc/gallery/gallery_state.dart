part of 'gallery_bloc.dart';

abstract class GalleryState {}

class GalleryInitial extends GalleryState {}

class FetchedSalonDataState extends GalleryState {}
