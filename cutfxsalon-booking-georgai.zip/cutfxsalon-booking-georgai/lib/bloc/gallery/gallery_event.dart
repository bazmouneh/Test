part of 'gallery_bloc.dart';

abstract class GalleryEvent {}

class GetSalonEvent extends GalleryEvent {}
