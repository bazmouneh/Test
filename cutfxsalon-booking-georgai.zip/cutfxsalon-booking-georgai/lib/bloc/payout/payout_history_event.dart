part of 'payout_history_bloc.dart';

abstract class PayoutHistoryEvent {}

class FetchPayoutHistoryEvent extends PayoutHistoryEvent {}
