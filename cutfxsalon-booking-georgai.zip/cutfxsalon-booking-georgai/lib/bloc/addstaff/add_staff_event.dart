part of 'add_staff_bloc.dart';

class AddStaffEvent {}

class SubmitEditProfileEvent extends AddStaffEvent {}

class ImageSelectClickEvent extends AddStaffEvent {}

class FetchUserProfileEvent extends AddStaffEvent {}
