part of 'request_details_bloc.dart';

abstract class RequestDetailsEvent {}

class FetchRequestDetailEvent extends RequestDetailsEvent {}
