part of 'add_service_bloc.dart';

abstract class AddServiceEvent {}

class CategoryDataFetchedEvent extends AddServiceEvent {}

class AddImageEvent extends AddServiceEvent {}
