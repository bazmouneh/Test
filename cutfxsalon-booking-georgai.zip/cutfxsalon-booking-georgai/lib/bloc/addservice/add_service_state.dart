part of 'add_service_bloc.dart';

abstract class AddServiceState {}

class AddServiceInitial extends AddServiceState {}

class CategoryDataFetchedState extends AddServiceState {}

class AddServiceAddImageState extends AddServiceState {}
