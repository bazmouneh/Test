part of 'staff_order_history_bloc.dart';

class StaffOrderHistoryEvent {}

class FetchOrderHistoryEvent extends StaffOrderHistoryEvent {}
