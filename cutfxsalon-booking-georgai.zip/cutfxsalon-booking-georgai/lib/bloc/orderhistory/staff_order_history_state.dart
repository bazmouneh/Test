part of 'staff_order_history_bloc.dart';

class StaffOrderHistoryState {}

class StaffOrderHistoryInitial extends StaffOrderHistoryState {}

class OrderHistoryDataFoundState extends StaffOrderHistoryState {}
