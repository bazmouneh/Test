part of 'login_bloc.dart';

abstract class LoginState {}

class LoginInitial extends LoginState {}
