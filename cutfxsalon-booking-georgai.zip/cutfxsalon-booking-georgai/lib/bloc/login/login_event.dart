part of 'login_bloc.dart';

abstract class LoginEvent {}
