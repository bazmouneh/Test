part of 'review_bloc.dart';

abstract class ReviewEvent {}

class FetchReviewsEvent extends ReviewEvent {}
