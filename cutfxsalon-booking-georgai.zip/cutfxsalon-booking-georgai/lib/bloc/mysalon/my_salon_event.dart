part of 'my_salon_bloc.dart';

abstract class MySalonEvent {}

class FetchSalonDataEvent extends MySalonEvent {
  FetchSalonDataEvent();
}
