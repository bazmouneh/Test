part of 'message_user_bloc.dart';

abstract class MessageUserState {}

class MessageUserInitial extends MessageUserState {}

class MessageUsersDataFoundState extends MessageUserState {}
