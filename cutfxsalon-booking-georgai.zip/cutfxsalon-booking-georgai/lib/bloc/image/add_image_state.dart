part of 'add_image_bloc.dart';

abstract class AddImageState {}

class AddImageInitial extends AddImageState {}

class ImageSelectState extends AddImageState {}
