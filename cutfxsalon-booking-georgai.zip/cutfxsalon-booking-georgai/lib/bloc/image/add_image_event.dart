part of 'add_image_bloc.dart';

abstract class AddImageEvent {}

class AddImageClickEvent extends AddImageEvent {}

class AddSubmitClickEvent extends AddImageEvent {}
