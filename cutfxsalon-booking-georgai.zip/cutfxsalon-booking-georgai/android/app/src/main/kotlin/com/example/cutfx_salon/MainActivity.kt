package com.example.cutfx_salon

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
